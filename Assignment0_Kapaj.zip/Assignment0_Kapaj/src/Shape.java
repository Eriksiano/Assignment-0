
//Eriksiano Kapaj
public class Shape {
	private String name;

	public Shape(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public double getArea() {
		return 0.0;
	}

	public void printDimension() {
		System.out.println("No Dimension");
	}
}

class Square extends Shape {
	double length, height;

	public Square(String name) {
		super(name); // inherits constructor from parent class
	}

	public void setDimension(double length, double height) {
		this.length = length;
		this.height = height;
	}

	public void printDimension() {
		System.out.println("Length : " + length + " & height : " + height);
	}

	public double getArea() {
		return length * height;
	}
}

class Circle extends Shape {
	private double radius;

	public Circle(String name) {
		super(name);
	}

	public void setDimension(double radius) {
		this.radius = radius;
	}

	public void printDimension() {
		System.out.println("radius : " + radius);
	}

	public double getArea() {
		return 3.14 * radius * radius;
	}
}

class Triangle extends Shape {
	private double a, b, c;

	public Triangle(String name) {
		super(name);
	}

	public void setDimension(double a, double b, double c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public void printDimension() {
		System.out.println("Side a : " + a + ", Side b : " + b + " & Side c : " + c);
	}

	public double getArea() {
		double s = (a + b + c) / 2;
		return Math.sqrt((s) * (s - a) * (s - b) * (s - c));
	}
}

class EquilateralTriangle extends Triangle {
	private double s1;

	public EquilateralTriangle(String name) {
		super(name);
	}

	public void setDimension(double s1) {
		super.setDimension(s1, s1, s1);
		this.s1 = s1;
	}
}
