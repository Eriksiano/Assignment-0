import java.util.Scanner;
//Eriksiano Kapaj
public class main {
	public static void main(String args[]) {

		Scanner scan = new Scanner(System.in);
		// creates  objects
		System.out.println("Enter length and height for Square :");
		Square square = new Square("Square");
		square.setDimension(scan.nextDouble(), scan.nextDouble());
		
		
		System.out.println("Enter radius for Circle :");
		Circle circle = new Circle("Circle");
		circle.setDimension(scan.nextDouble());
		
		
		System.out.println("Enter a, b and c for Triangle :");
		Triangle triangle = new Triangle("Triangle");
		triangle.setDimension(scan.nextDouble(), scan.nextDouble(), scan.nextDouble());
		System.out.println("Enter side for EquilateralTriangle :");
		EquilateralTriangle equilateraltriangle = new EquilateralTriangle("EquilateralTriangle");
		equilateraltriangle.setDimension(scan.nextDouble());

		// prints objects
		System.out.println("\n" + square.getName());
		square.printDimension();
		System.out.println("Area: " + square.getArea());
		
		
		System.out.println("\n" + circle.getName());
		circle.printDimension();
		System.out.println("Area: " + circle.getArea());
		
		
		System.out.println("\n" + triangle.getName());
		triangle.printDimension();
		System.out.println("Area: " + triangle.getArea());
		System.out.println("\n" + equilateraltriangle.getName());
		equilateraltriangle.printDimension();
		System.out.println("Area: " + equilateraltriangle.getArea());

	}
}
